"""
yolo_detector.py

Advanced YOLOv8-based person detection module with best engineering practices:
 - Logging and error handling
 - Configurable thresholds
 - Optional GPU usage (auto detection)
 - Preprocessing (e.g., gamma correction)
 - Advanced bounding-box filtering
"""
import logging
import cv2
import numpy as np
import torch
from ultralytics import YOLO

# ------------------------------------------------------------------------------
# Setup logging
# ------------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------
# YOLO Detector Class
# ------------------------------------------------------------------------------
class YOLODetector:
    """
    A robust YOLOv8 detection class for advanced usage.
    - Allows GPU/CPU selection or 'auto'
    - Provides image preprocessing for consistent detection
    - Filters bounding boxes beyond standard confidence or NMS thresholds
    """

    def __init__(
        self,
        model_path: str = "yolov8n.pt",
        device: str = "auto",           # "auto", "cpu", or "cuda:0"
        conf_thres: float = 0.5,        # YOLO confidence threshold
        iou_thres: float = 0.45,        # YOLO NMS IoU threshold
        person_class_id: int = 0,       # "person" is usually class 0 in COCO
        gamma: float = 1.0,             # for gamma correction
        advanced_box_filter: bool = True,
    ):
        """
        Args:
            model_path       (str): Path to YOLO weights, e.g. 'yolov8n.pt' or custom.
            device          (str): 'cpu', 'cuda:0', or 'auto' for auto detection.
            conf_thres    (float): Confidence threshold for YOLO detection.
            iou_thres     (float): IoU threshold for NMS.
            person_class_id (int): Class ID for 'person' in the YOLO model.
            gamma         (float): Apply gamma correction if != 1.0
            advanced_box_filter (bool): Enable advanced bounding-box filtering logic.
        """
        # Resolve device if user gave 'auto'
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"

        self.device = device

        # Load YOLO model
        self.model = YOLO(model_path)
        self.model.to(self.device)
        self.model.overrides["conf"] = conf_thres
        self.model.overrides["iou"] = iou_thres

        self.person_class_id = person_class_id
        self.gamma = gamma
        self.advanced_box_filter = advanced_box_filter

        self.cap = None

        logger.info("Initializing YOLODetector with model=%s, device=%s", model_path, self.device)

    def open_camera(self, camera_index: int = 0) -> bool:
        """
        Opens a webcam stream on the given index.
        Returns True if successful, False otherwise.

        Args:
            camera_index (int): Typically 0 (default cam), 1 (external), etc.
        """
        logger.info("Opening camera at index %d", camera_index)
        self.cap = cv2.VideoCapture(camera_index)
        if not self.cap.isOpened():
            logger.error("Failed to open camera index %d", camera_index)
            return False
        return True

    def read_frame(self):
        """
        Reads a frame from the camera, applies optional preprocessing, and returns it.
        Returns:
            frame (ndarray): BGR image or None if fail
        """
        if self.cap is None or not self.cap.isOpened():
            logger.error("Camera is not opened or not available.")
            return None

        ret, frame = self.cap.read()
        if not ret:
            logger.warning("Failed to read frame from camera.")
            return None

        # Optional: Gamma correction or any advanced image processing
        if self.gamma != 1.0:
            frame = self.apply_gamma_correction(frame, self.gamma)

        return frame

    def detect(self, frame: np.ndarray):
        """
        Runs YOLO detection on the provided frame.
        Args:
            frame (ndarray): BGR image
        Returns:
            boxes (List[Tuple[int,int,int,int]]): bounding boxes for 'person' class
            confidences (List[float]): confidence scores
        """
        # YOLOv8 inference
        results = self.model(frame, stream=False)[0]

        boxes = []
        confidences = []

        for box in results.boxes:
            class_id = int(box.cls[0])
            conf = float(box.conf[0])
            if class_id == self.person_class_id:
                # raw coords
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                if self.advanced_box_filter and not self.box_passes_filter(x1, y1, x2, y2, frame.shape):
                    continue
                boxes.append((x1, y1, x2, y2))
                confidences.append(conf)

        return boxes, confidences

    def close_camera(self):
        """ Safely close camera resources. """
        if self.cap and self.cap.isOpened():
            self.cap.release()

    # --------------------------------------------------------------------------
    # Image Preprocessing Utilities
    # --------------------------------------------------------------------------
    @staticmethod
    def apply_gamma_correction(frame: np.ndarray, gamma: float) -> np.ndarray:
        """
        Applies gamma correction to the BGR frame.
        Args:
            frame (ndarray): BGR image
            gamma (float): gamma value
        Returns:
            corrected (ndarray): gamma-corrected BGR image
        """
        inv_gamma = 1.0 / gamma
        table = np.array([(i / 255.0) ** inv_gamma * 255 for i in range(256)]).astype("uint8")
        return cv2.LUT(frame, table)

    def box_passes_filter(self, x1, y1, x2, y2, shape):
        """
        Advanced bounding-box filtering logic.
        For instance, filter out extremely small boxes or 
        boxes that don't meet aspect ratio constraints, etc.
        Args:
            x1,y1,x2,y2 (int): bounding box coords
            shape (tuple): (height, width, channels)
        Returns:
            bool: True if passes filter
        """
        h, w, _ = shape
        box_w = x2 - x1
        box_h = y2 - y1

        # Filter out boxes that are too small
        min_area = 50 * 50  # e.g., 50x50 px
        if box_w * box_h < min_area:
            logger.debug("Filtering out box < min_area: (%d, %d, %d, %d)", x1, y1, x2, y2)
            return False

        # Filter out bizarre aspect ratios (optional)
        aspect_ratio = box_w / float(box_h + 1e-6)
        if aspect_ratio > 5 or aspect_ratio < 0.2:
            logger.debug("Filtering out odd aspect ratio: %f", aspect_ratio)
            return False

        # Additional logic can be added here
        return True


# -------------------------------------------------------------------------
# Example usage (comment out or remove if not needed)
# -------------------------------------------------------------------------
if __name__ == "__main__":
    detector = YOLODetector(
        model_path="yolov8n.pt",
        device="auto",        # tries cuda if available, else cpu
        conf_thres=0.5,
        iou_thres=0.45,
        gamma=1.0,
        advanced_box_filter=True
    )
    opened = detector.open_camera(0)
    if not opened:
        print("Could not open camera.")
        exit(1)

    while True:
        frame = detector.read_frame()
        if frame is None:
            continue

        boxes, confs = detector.detect(frame)
        # Draw
        for (x1, y1, x2, y2), c in zip(boxes, confs):
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"Person {c:.2f}", (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1)

        cv2.imshow("YOLO Detector", frame)
        if cv2.waitKey(1) & 0xFF == 27:  # press ESC to quit
            break

    detector.close_camera()
    cv2.destroyAllWindows()
