# pose_estimator.py

from ultralytics import YOLO
import numpy as np
import cv2

class PoseEstimator:
    def __init__(self):
        self.model = YOLO("yolov8n-pose.pt")  # Downloaded on first run

    def get_pose(self, frame):
        """
        Runs YOLOv8 pose estimation on the input frame.

        Returns:
            - keypoints: List of (x, y) tuples (normalized)
            - annotated_frame: Frame with pose drawn
        """
        results = self.model.predict(frame, verbose=False)[0]
        annotated_frame = results.plot()

        # Extract keypoints of first detected person
        if len(results.keypoints) == 0:
            return [], annotated_frame

        # Assume first person only for now
        keypoints = results.keypoints.xy[0].cpu().numpy()  # shape (17, 2)
        keypoints = [(x / frame.shape[1], y / frame.shape[0]) for x, y in keypoints]

        return keypoints, annotated_frame
