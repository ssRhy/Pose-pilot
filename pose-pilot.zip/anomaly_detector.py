import numpy as np
import time

class AnomalyDetector:
    def __init__(self, angle_threshold=55, history_window=10):
        self.history = []
        self.timestamp_history = []
        self.angle_threshold = angle_threshold
        self.window = history_window  # seconds

    def is_fall_like(self, keypoints):
        if len(keypoints) < 27:
            return False

        def angle(a, b, c):
            a, b, c = map(np.array, (a, b, c))
            ba = a - b
            bc = c - b
            cosine = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc) + 1e-6)
            return np.arccos(cosine) * 180 / np.pi

        # Body angle: shoulder-hip-knee
        left_angle = angle(keypoints[11], keypoints[23], keypoints[25])
        right_angle = angle(keypoints[12], keypoints[24], keypoints[26])
        avg_body_angle = (left_angle + right_angle) / 2

        # Neck angle: shoulder-neck-head (using nose as proxy for head)
        neck_angle = angle(keypoints[0], keypoints[11], keypoints[12])  # 0 = nose

        now = time.time()
        is_bad = avg_body_angle < self.angle_threshold or neck_angle < 50

        if is_bad:
            self.timestamp_history.append(now)

        # Clean old entries outside time window
        self.timestamp_history = [t for t in self.timestamp_history if now - t < self.window]

        # Trigger alert if posture has been bad for full window
        return len(self.timestamp_history) >= self.window
