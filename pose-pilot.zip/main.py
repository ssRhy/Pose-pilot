# import sys
# import traceback
# import cv2
# import numpy as np
# import time
# import random

# from PyQt5.QtCore import QTimer, Qt, QThread, pyqtSignal, QMutex
# from PyQt5.QtGui import QImage, QPixmap, QFont, QColor, QPalette
# from PyQt5.QtWidgets import (
#     QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
#     QLabel, QPushButton, QTextEdit, QLineEdit, QSplitter, QFrame,
#     QMessageBox, QSlider
# )

# # ---- Import your modules (adjust paths as needed) ----
# from yolo_detector import YOLODetector
# from pose_estimator import PoseEstimator
# from anomaly_detector import AnomalyDetector

# # Gemini 2.0
# from google import genai


# class YOLOWorker(QThread):
#     """
#     A dedicated thread for YOLO detection + YOLO-Pose.
#     This prevents the main GUI thread from freezing during heavy computations.
#     """
#     new_frame = pyqtSignal(np.ndarray, np.ndarray, list)  
#     # emits (annotated_frame, unscaled_frame, keypoints_list)

#     def __init__(self, detector: YOLODetector, pose_estimator: PoseEstimator, anomaly_detector: AnomalyDetector, parent=None):
#         super().__init__(parent)
#         self.detector = detector
#         self.pose_estimator = pose_estimator
#         self.anomaly_detector = anomaly_detector
#         self.running = True
#         self.mutex = QMutex()

#     def run(self):
#         while self.running:
#             try:
#                 self.mutex.lock()
#                 frame = self.detector.read_frame()
#                 self.mutex.unlock()

#                 if frame is None:
#                     time.sleep(0.02)  # no frame, try again
#                     continue

#                 # 1) YOLO bounding-box detection
#                 boxes, confs = self.detector.detect(frame)

#                 # Optional advanced filter: skip boxes below conf threshold (again)
#                 # If 'conf' is already applied in your yolo_detector, you can skip this.
#                 filtered_boxes = []
#                 filtered_confs = []
#                 for (x1, y1, x2, y2), c in zip(boxes, confs):
#                     if c >= 0.5:  # or any advanced threshold or slider-based threshold
#                         filtered_boxes.append((x1, y1, x2, y2))
#                         filtered_confs.append(c)

#                 # 2) YOLO-Pose
#                 keypoints, annotated_frame = self.pose_estimator.get_pose(frame)

#                 # 3) Draw bounding boxes on the annotated frame
#                 for (x1, y1, x2, y2) in filtered_boxes:
#                     cv2.rectangle(
#                         annotated_frame, (x1, y1), (x2, y2), (0, 255, 0), 2
#                     )

#                 # Signal the main thread with (annotated frame, raw frame, keypoints)
#                 self.new_frame.emit(annotated_frame, frame, keypoints)

#             except Exception as e:
#                 print(f"[YOLOWorker] Exception in run loop: {e}")
#                 traceback.print_exc()
#                 time.sleep(0.05)

#     def stop(self):
#         self.running = False


# class MainWindow(QMainWindow):
#     def __init__(self, api_key="AIzaSyA71g53Gw1831fzaZWPZUcjXTShbmWx7fQ", parent=None):
#         super().__init__(parent)
#         self.setWindowTitle("Smart Risk Detector - Advanced UI")
#         self.setGeometry(100, 50, 1400, 800)

#         # ---- STYLING & LAYOUT ----
#         self._init_style()
#         self._init_gemini(api_key)
#         self._init_modules()
#         self._init_ui()

#         # Thread for YOLO + YOLO-Pose in background
#         self.worker = YOLOWorker(self.detector, self.pose_estimator, self.anomaly_detector)
#         self.worker.new_frame.connect(self.on_new_frame)
#         self.worker.start()

#     def speak_dynamic_warning(self, context="Your posture is poor."):
#         now = time.time()
#         if now - self.last_spoken < 15:  # avoid spamming every second
#             return

#         variations = [
#             f"Hey, take care of your back! {context}",
#             f"Uh oh, seems like you’ve been slouching for a while. Fix your posture.",
#             f"I've noticed you're leaning again. Sit upright please.",
#             f"You're in a risky posture. Adjust now to stay safe!",
#             f"Bad posture detected. Straighten up before it's too late!",
#             f"This position isn’t great. Come on, sit properly!"
#         ]
#         message = random.choice(variations)
#         self.tts_engine.say(message)
#         self.tts_engine.runAndWait()
#         self.last_spoken = now

#         # Also show in Gemini-style chat
#         self.chat_display.append(f"<b>Gemini:</b> {message}")


#     def _init_style(self):
#         # Optional color palette
#         palette = QPalette()
#         palette.setColor(QPalette.Window, QColor(40, 44, 52))  # dark background
#         self.setPalette(palette)

#         font = QFont("Segoe UI", 10)
#         self.setFont(font)

#         # Example advanced QSS styling
#         self.setStyleSheet("""
#             QMainWindow {
#                 background-color: #282C34;
#             }
#             QLabel#videoLabel {
#                 background-color: #333;
#                 border: 2px solid #555;
#             }
#             QLabel#alertLabel {
#                 color: #0f0; 
#                 font-size: 18px;
#             }
#             QLineEdit {
#                 background-color: #555; 
#                 color: #fff; 
#                 border: 1px solid #aaa;
#             }
#             QPushButton {
#                 background-color: #007ACC; 
#                 color: #fff; 
#                 padding: 5px;
#                 border-radius: 4px;
#             }
#             QPushButton:hover {
#                 background-color: #3399FF;
#             }
#             QTextEdit {
#                 background-color: #333; 
#                 color: #fff;
#             }
#             QSlider::groove:horizontal {
#                 background: #444;
#                 height: 6px;
#                 border-radius: 3px;
#             }
#             QSlider::handle:horizontal {
#                 background: #888;
#                 width: 12px;
#                 margin: -4px 0;
#                 border-radius: 6px;
#             }
#         """)

#     def _init_gemini(self, api_key):
#         try:
#             self.gemini_client = genai.Client(api_key=api_key)
#         except Exception as e:
#             print(f"[Gemini Init] Failed to initialize Gemini with key: {e}")
#             self.gemini_client = None

#     def _init_modules(self):
#         # YOLO for bounding box detection
#         self.detector = YOLODetector(
#             model_path="yolov8n.pt",
#             device="auto",  
#             conf_thres=0.5,
#             iou_thres=0.45,
#             gamma=1.0
#         )

#         # Attempt to open camera
#         if not self.detector.open_camera(1):
#             QMessageBox.critical(self, "Camera Error", "Failed to open default camera (index 0).")

#         # YOLO-Pose for keypoint detection
#         self.pose_estimator = PoseEstimator()

#         # Basic angle-based anomaly detection
#         self.anomaly_detector = AnomalyDetector()

#     def _init_ui(self):
#         central_widget = QWidget()
#         self.setCentralWidget(central_widget)

#         main_layout = QHBoxLayout(central_widget)
#         main_layout.setContentsMargins(0, 0, 0, 0)
#         main_layout.setSpacing(0)

#         # Left: Video feed
#         self.video_label = QLabel()
#         self.video_label.setObjectName("videoLabel")
#         self.video_label.setFixedSize(900, 700)

#         # Right: Chat + Analysis
#         right_panel = self._init_right_panel()

#         splitter = QSplitter(Qt.Horizontal)
#         left_frame = QFrame()
#         left_layout = QVBoxLayout(left_frame)
#         left_layout.addWidget(self.video_label)
#         splitter.addWidget(left_frame)
#         splitter.addWidget(right_panel)
#         splitter.setStretchFactor(0, 6)
#         splitter.setStretchFactor(1, 4)

#         main_layout.addWidget(splitter)

#     def _init_right_panel(self):
#         container = QFrame()
#         container.setFrameShape(QFrame.StyledPanel)
#         layout = QVBoxLayout(container)
#         layout.setSpacing(15)

#         # Posture Alert
#         self.alert_label = QLabel("No Anomalies Detected")
#         self.alert_label.setObjectName("alertLabel")
#         layout.addWidget(self.alert_label)

#         self.counter_label = QLabel("Bad Posture Duration: 0s")
#         self.counter_label.setStyleSheet("color: #ccc; font-size: 14px;")
#         layout.addWidget(self.counter_label)
#         self.bad_posture_start = None


#         # Confidence Slider
#         conf_slider_label = QLabel("Detection Confidence Threshold")
#         conf_slider_label.setStyleSheet("color: #fff; font-size: 14px;")
#         layout.addWidget(conf_slider_label)

#         self.conf_slider = QSlider(Qt.Horizontal)
#         self.conf_slider.setRange(10, 90)  # 0.1 to 0.9
#         self.conf_slider.setValue(50)      
#         self.conf_slider.valueChanged.connect(self.on_confidence_changed)
#         layout.addWidget(self.conf_slider)

#         # Chat Title
#         chat_title = QLabel("Gemini 2.0 Posture Insights")
#         chat_title.setStyleSheet("color: #fff; font-weight: bold; font-size: 16px;")
#         layout.addWidget(chat_title)

#         # Chat Display
#         self.chat_display = QTextEdit()
#         self.chat_display.setReadOnly(True)
#         layout.addWidget(self.chat_display, stretch=1)

#         # Query + Button
#         query_layout = QHBoxLayout()
#         self.query_input = QLineEdit()
#         self.query_input.setPlaceholderText("Ask about posture risk or solutions...")
#         query_layout.addWidget(self.query_input)

#         send_btn = QPushButton("Send")
#         send_btn.clicked.connect(self.on_send_chat)
#         query_layout.addWidget(send_btn)

#         layout.addLayout(query_layout)

#         return container

#     def on_confidence_changed(self):
#         """
#         Dynamically update YOLO bounding box confidence threshold based on slider.
#         """
#         val = self.conf_slider.value()
#         conf_thres = float(val) / 100.0
#         self.detector.model.overrides["conf"] = conf_thres

#     def on_new_frame(self, annotated_frame, raw_frame, keypoints):
#         scaled_kpts = self._scale_keypoints(keypoints, annotated_frame.shape)
#         is_fall = self.anomaly_detector.is_fall_like(scaled_kpts)

#         if is_fall:
#             self.alert_label.setText("⚠️ Persistent Bad Posture!")
#             self.alert_label.setStyleSheet("color: #f00; font-size: 18px;")
#             self.speak_dynamic_warning("Persistent forward bend detected.")
#         else:
#             self.alert_label.setText("No Anomalies Detected")
#             self.alert_label.setStyleSheet("color: #0f0; font-size: 18px;")

#         rgb_frame = cv2.cvtColor(annotated_frame, cv2.COLOR_BGR2RGB)
#         h, w, ch = rgb_frame.shape
#         bytes_per_line = ch * w
#         qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)

#         self.video_label.setPixmap(QPixmap.fromImage(qt_image))


#     def on_send_chat(self):
#         user_query = self.query_input.text().strip()
#         if not user_query:
#             return

#         self.chat_display.append(f"<b>You:</b> {user_query}")

#         response_text = self._gemini_explain_posture(user_query)
#         if not response_text:
#             response_text = "I'm sorry, I can't respond right now."

#         self.chat_display.append(f"<b>Gemini:</b> {response_text}")
#         self.query_input.clear()

#     def _gemini_explain_posture(self, query):
#         if not self.gemini_client:
#             return "Gemini not available. Please check your API key or connection."

#         prompt = (
#             "You are a medical posture risk assistant. "
#             "User posture is somewhat unusual. "
#             f"User says: '{query}'. "
#             "Please provide insight or safety tips in a concise manner."
#         )
#         try:
#             response = self.gemini_client.models.generate_content(
#                 model="gemini-2.0-flash",
#                 contents=prompt
#             )
#             return response.text
#         except Exception as e:
#             print(f"[Gemini Error] {e}")
#             return ""

#     def _scale_keypoints(self, keypoints, shape):
#         """
#         YOLO-Pose keypoints are returned as absolute pixel coords
#         or normalized [0..1], depending on your `pose_estimator`.
#         If they're normalized, we convert them here. If they're
#         already in pixel space, you can just return them as-is.
#         """
#         h, w, _ = shape
#         scaled = []
#         for (x, y) in keypoints:
#             px = int(x * w)   # if x is in [0..1], multiply by width
#             py = int(y * h)   # if y is in [0..1], multiply by height
#             scaled.append((px, py))
#         return scaled

#     def closeEvent(self, event):
#         self.worker.stop()
#         self.worker.wait()
#         self.detector.close_camera()
#         event.accept()


# # -------------------------------------------------------------------------
# # Run the App
# # -------------------------------------------------------------------------
# if __name__ == "__main__":
#     app = QApplication(sys.argv)
#     window = MainWindow(api_key="YOUR_REAL_GEMINI_2_KEY")
#     window.show()
#     sys.exit(app.exec_())
import sys
import traceback
import cv2
import numpy as np
import time
import random
import pyttsx3
import base64
from io import BytesIO

from PyQt5.QtCore import QTimer, Qt, QThread, pyqtSignal, QMutex
from PyQt5.QtGui import QImage, QPixmap, QFont, QColor, QPalette
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QLineEdit, QSplitter, QFrame,
    QMessageBox, QSlider
)

from yolo_detector import YOLODetector
from pose_estimator import PoseEstimator
from anomaly_detector import AnomalyDetector

from google import genai


class YOLOWorker(QThread):
    new_frame = pyqtSignal(np.ndarray, np.ndarray, list)

    def __init__(self, detector: YOLODetector, pose_estimator: PoseEstimator, anomaly_detector: AnomalyDetector, parent=None):
        super().__init__(parent)
        self.detector = detector
        self.pose_estimator = pose_estimator
        self.anomaly_detector = anomaly_detector
        self.running = True
        self.mutex = QMutex()

    def run(self):
        while self.running:
            try:
                self.mutex.lock()
                frame = self.detector.read_frame()
                self.mutex.unlock()

                if frame is None:
                    time.sleep(0.02)
                    continue

                boxes, confs = self.detector.detect(frame)

                filtered_boxes = []
                filtered_confs = []
                for (x1, y1, x2, y2), c in zip(boxes, confs):
                    if c >= 0.5:
                        filtered_boxes.append((x1, y1, x2, y2))
                        filtered_confs.append(c)

                keypoints, annotated_frame = self.pose_estimator.get_pose(frame)

                for (x1, y1, x2, y2) in filtered_boxes:
                    cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

                self.new_frame.emit(annotated_frame, frame, keypoints)

            except Exception as e:
                print(f"[YOLOWorker] Exception in run loop: {e}")
                traceback.print_exc()
                time.sleep(0.05)

    def stop(self):
        self.running = False


class MainWindow(QMainWindow):
    def __init__(self, api_key="AIzaSyA71g53Gw1831fzaZWPZUcjXTShbmWx7fQ", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Smart Risk Detector - Advanced UI")
        self.setGeometry(100, 50, 1400, 800)

        self.tts_engine = pyttsx3.init()
        self.last_spoken = 0

        self._init_style()
        self._init_gemini(api_key)
        self._init_modules()
        self._init_ui()

        self.worker = YOLOWorker(self.detector, self.pose_estimator, self.anomaly_detector)
        self.worker.new_frame.connect(self.on_new_frame)
        self.worker.start()

    def speak_dynamic_warning(self, context="Your posture is poor."):
        now = time.time()
        if now - self.last_spoken < 15:
            return

        variations = [
            f"Hey, take care of your back! {context}",
            f"Uh oh, seems like you’ve been slouching for a while. Fix your posture.",
            f"I've noticed you're leaning again. Sit upright please.",
            f"You're in a risky posture. Adjust now to stay safe!",
            f"Bad posture detected. Straighten up before it's too late!",
            f"This position isn’t great. Come on, sit properly!"
        ]
        message = random.choice(variations)
        self.tts_engine.say(message)
        self.tts_engine.runAndWait()
        self.last_spoken = now

        self.chat_display.append(f"<b>Gemini:</b> {message}")

    def _init_style(self):
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(40, 44, 52))
        self.setPalette(palette)

        font = QFont("Segoe UI", 10)
        self.setFont(font)

        self.setStyleSheet("""
            QMainWindow { background-color: #282C34; }
            QLabel#videoLabel { background-color: #333; border: 2px solid #555; }
            QLabel#alertLabel { color: #0f0; font-size: 18px; }
            QLineEdit { background-color: #555; color: #fff; border: 1px solid #aaa; }
            QPushButton { background-color: #007ACC; color: #fff; padding: 5px; border-radius: 4px; }
            QPushButton:hover { background-color: #3399FF; }
            QTextEdit { background-color: #333; color: #fff; }
            QSlider::groove:horizontal { background: #444; height: 6px; border-radius: 3px; }
            QSlider::handle:horizontal { background: #888; width: 12px; margin: -4px 0; border-radius: 6px; }
        """)

    def _init_gemini(self, api_key):
        try:
            self.gemini_client = genai.Client(api_key=api_key)
        except Exception as e:
            print(f"[Gemini Init] Failed to initialize Gemini with key: {e}")
            self.gemini_client = None

    def _init_modules(self):
        self.detector = YOLODetector(model_path="yolov8n.pt", device="auto", conf_thres=0.5, iou_thres=0.45, gamma=1.0)
        if not self.detector.open_camera(0):
            QMessageBox.critical(self, "Camera Error", "Failed to open default camera (index 1).")

        self.pose_estimator = PoseEstimator()
        self.anomaly_detector = AnomalyDetector()

    def _init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.video_label = QLabel()
        self.video_label.setObjectName("videoLabel")
        self.video_label.setFixedSize(900, 700)

        right_panel = self._init_right_panel()

        splitter = QSplitter(Qt.Horizontal)
        left_frame = QFrame()
        left_layout = QVBoxLayout(left_frame)
        left_layout.addWidget(self.video_label)
        splitter.addWidget(left_frame)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(0, 6)
        splitter.setStretchFactor(1, 4)

        main_layout.addWidget(splitter)

    def _init_right_panel(self):
        container = QFrame()
        container.setFrameShape(QFrame.StyledPanel)
        layout = QVBoxLayout(container)
        layout.setSpacing(15)

        self.alert_label = QLabel("No Anomalies Detected")
        self.alert_label.setObjectName("alertLabel")
        layout.addWidget(self.alert_label)

        self.counter_label = QLabel("Bad Posture Duration: 0s")
        self.counter_label.setStyleSheet("color: #ccc; font-size: 14px;")
        layout.addWidget(self.counter_label)
        self.bad_posture_start = None

        conf_slider_label = QLabel("Detection Confidence Threshold")
        conf_slider_label.setStyleSheet("color: #fff; font-size: 14px;")
        layout.addWidget(conf_slider_label)

        self.conf_slider = QSlider(Qt.Horizontal)
        self.conf_slider.setRange(10, 90)
        self.conf_slider.setValue(50)
        self.conf_slider.valueChanged.connect(self.on_confidence_changed)
        layout.addWidget(self.conf_slider)

        chat_title = QLabel("Gemini 2.0 Posture Insights")
        chat_title.setStyleSheet("color: #fff; font-weight: bold; font-size: 16px;")
        layout.addWidget(chat_title)

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display, stretch=1)

        query_layout = QHBoxLayout()
        self.query_input = QLineEdit()
        self.query_input.setPlaceholderText("Ask about posture risk or solutions...")
        query_layout.addWidget(self.query_input)

        send_btn = QPushButton("Send")
        send_btn.clicked.connect(self.on_send_chat)
        query_layout.addWidget(send_btn)

        layout.addLayout(query_layout)
        return container

    def on_confidence_changed(self):
        val = self.conf_slider.value()
        conf_thres = float(val) / 100.0
        self.detector.model.overrides["conf"] = conf_thres

    def on_new_frame(self, annotated_frame, raw_frame, keypoints):
        # Convert the frame to a JPEG for Gemini image prompt
        success, buffer = cv2.imencode(".jpg", annotated_frame)
        if success and self.gemini_client:
            b64img = base64.b64encode(buffer).decode("utf-8")
            prompt = [
                {"text": "Please determine if this image shows a bad or dangerous human posture."},
                {"inline_data": {"mime_type": "image/jpeg", "data": b64img}}
            ]
            try:
                result = self.gemini_client.models.generate_content(
                    model="gemini-pro-vision",
                    contents=prompt
                )
                response = result.text.lower()
                if "bad posture" in response or "leaning" in response or "slouching" in response:
                    self.alert_label.setText("⚠️ Gemini Alert: Bad Posture!")
                    self.alert_label.setStyleSheet("color: #f00; font-size: 18px;")
                    self.speak_dynamic_warning("Gemini detected improper posture.")
                else:
                    self.alert_label.setText("No Anomalies Detected")
                    self.alert_label.setStyleSheet("color: #0f0; font-size: 18px;")
            except Exception as e:
                print("[Gemini Vision Error]", e)

        rgb_frame = cv2.cvtColor(annotated_frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(qt_image))

    def on_send_chat(self):
        user_query = self.query_input.text().strip()
        if not user_query:
            return

        self.chat_display.append(f"<b>You:</b> {user_query}")
        response_text = self._gemini_explain_posture(user_query)
        if not response_text:
            response_text = "I'm sorry, I can't respond right now."
        self.chat_display.append(f"<b>Gemini:</b> {response_text}")
        self.query_input.clear()

    def _gemini_explain_posture(self, query):
        if not self.gemini_client:
            return "Gemini not available. Please check your API key or connection."

        prompt = (
            "You are a medical posture risk assistant. "
            "User posture is somewhat unusual. "
            f"User says: '{query}'. "
            "Please provide insight or safety tips in a concise manner."
        )
        try:
            response = self.gemini_client.models.generate_content(
                model="gemini-2.0-flash",
                contents=prompt
            )
            return response.text
        except Exception as e:
            print(f"[Gemini Error] {e}")
            return ""

    def _scale_keypoints(self, keypoints, shape):
        h, w, _ = shape
        scaled = []
        for (x, y) in keypoints:
            px = int(x * w)
            py = int(y * h)
            scaled.append((px, py))
        return scaled

    def closeEvent(self, event):
        self.worker.stop()
        self.worker.wait()
        self.detector.close_camera()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow(api_key="AIzaSyA71g53Gw1831fzaZWPZUcjXTShbmWx7fQ")
    window.show()
    sys.exit(app.exec_())