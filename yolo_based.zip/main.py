import sys
import time
import random
import cv2
import numpy as np
from flask import Flask, request, jsonify, send_from_directory
import base64
import os

app = Flask(__name__, static_folder='static')

@app.route('/')
def root():
    # Serve index.html from static folder
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/detect_posture', methods=['POST'])
def detect_posture():
    data = request.get_json()
    if not data or 'image' not in data:
        return jsonify({'error': 'No image data'}), 400

    b64_img = data['image']
    # We expect something like "data:image/jpeg;base64,/9j/4AAQSkZ..."
    # So split off the "data:image/jpeg;base64," part
    header, b64_data = b64_img.split(',', 1)
    img_bytes = base64.b64decode(b64_data)

    np_arr = np.frombuffer(img_bytes, np.uint8)
    frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    # Here you'd run YOLO or posture detection
    # posture = run_your_pose_detection(frame)
    posture = "perfect"  # For example

    return jsonify({'posture': posture})
from PyQt5.QtCore import QThread, pyqtSignal, QMutex, Qt, QTimer
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QHBoxLayout,
    QVBoxLayout, QFrame, QSplitter, QPushButton,
    QLineEdit, QSlider, QMessageBox
)
from PyQt5.QtGui import QImage, QPixmap, QColor, QPalette, QFont

# Import your modules
from yolo_detector import YOLODetector
from pose_estimator import PoseEstimator
from anomaly_detector import AnomalyDetector

class DetectionWorker(QThread):
    """
    QThread for real-time posture detection:
      1) Capture frames
      2) YOLO detect main person
      3) YOLOv8 Pose => keypoints
      4) Compare keypoints to baseline or 'fall_like'
    """
    frame_ready = pyqtSignal(np.ndarray, list, bool)  
    # (annotated_frame, keypoints, is_bad_posture)

    def __init__(self, yolo_det, pose_est, anomaly_det, parent=None):
        super().__init__(parent)
        self.detector = yolo_det
        self.pose_estimator = pose_est
        self.anomaly_detector = anomaly_det
        self._running = True
        self.mutex = QMutex()

    def run(self):
        while self._running:
            self.mutex.lock()
            frame = self.detector.read_frame()
            self.mutex.unlock()

            if frame is None:
                self.msleep(20)
                continue

            # Detect persons
            boxes, confs = self.detector.detect(frame)
            if not boxes:
                annotated_frame = frame.copy()
                self.frame_ready.emit(annotated_frame, [], False)
                self.msleep(20)
                continue

            # If multiple persons, pick the highest confidence
            max_conf_idx = max(range(len(confs)), key=lambda i: confs[i])
            x1, y1, x2, y2 = boxes[max_conf_idx]

            # Pose Estimation
            kp_norm, annotated_frame = self.pose_estimator.get_pose(frame)
            kp_abs = self._scale_keypoints(kp_norm, frame.shape)

            # Decide posture based on baseline or fallback
            if self.anomaly_detector.has_baseline():
                is_bad = self.anomaly_detector.is_deviated_from_baseline(kp_abs)
            else:
                is_bad = self.anomaly_detector.is_fall_like(kp_abs)

            self.frame_ready.emit(annotated_frame, kp_abs, is_bad)
            self.msleep(20)

    def stop(self):
        self._running = False

    def _scale_keypoints(self, kp_normalized, shape):
        h, w, _ = shape
        return [(x * w, y * h) for (x, y) in kp_normalized]


class PostureApp(QMainWindow):
    """
    Main PyQt Application with:
      - Real-time video feed
      - "Set Baseline" button
      - "Alert" button that blinks if posture is bad
      - Confidence slider
      - 4-minute 'bad posture' logic is optional or can remain
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Real-Time Posture Detector (Baseline Mode)")
        self.setGeometry(100, 100, 1300, 700)

        # 4-minute "continuous bad posture" logic
        self.bad_posture_start = None
        self.BAD_POSTURE_THRESHOLD = 4 * 60  # 4 minutes

        # For blinking button
        self.alert_blink_state = False

        self._init_style()
        self._init_modules()
        self._init_ui()

        # Worker
        self.worker = DetectionWorker(
            self.detector, self.pose_estimator, self.anomaly_detector
        )
        self.worker.frame_ready.connect(self.on_frame_ready)
        self.worker.start()

        # Timer for blinking alert
        self.blink_timer = QTimer()
        self.blink_timer.timeout.connect(self._toggle_alert_button)
        self.blink_timer.start(500)  # blink every 0.5s

    def _init_style(self):
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(40, 44, 52))
        self.setPalette(palette)

        font = QFont("Segoe UI", 10)
        self.setFont(font)

        self.setStyleSheet("""
            QMainWindow { background-color: #282C34; }
            QLabel#videoLabel { background-color: #333; border: 2px solid #555; }
            QLabel#alertLabel { color: #0f0; font-size: 18px; }
            QLineEdit { background-color: #555; color: #fff; border: 1px solid #aaa; }
            QPushButton { background-color: #007ACC; color: #fff; padding: 5px; border-radius: 4px; }
            QPushButton:hover { background-color: #3399FF; }
            QSlider::groove:horizontal { background: #444; height: 6px; border-radius: 3px; }
            QSlider::handle:horizontal { background: #888; width: 12px; margin: -4px 0; border-radius: 6px; }
        """)

    def _init_modules(self):
        self.detector = YOLODetector(
            model_path="yolov8n.pt",
            device="auto",
            conf_thres=0.7,
            iou_thres=0.45,
            gamma=1.0,
            advanced_box_filter=True
        )
        if not self.detector.open_camera(0):
            QMessageBox.critical(self, "Camera Error", "Failed to open camera at index 0.")

        self.pose_estimator = PoseEstimator()

        # AnomalyDetector with baseline logic
        self.anomaly_detector = AnomalyDetector(
            body_angle_threshold=55,
            neck_angle_threshold=50,
            history_window=10,          # old angle-based logic window
            deviation_angle_threshold=15  # how many degrees away from baseline is "bad"
        )

    def _init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Left side: Video feed
        self.video_label = QLabel()
        self.video_label.setObjectName("videoLabel")
        self.video_label.setFixedSize(900, 640)

        # Right side: Controls
        right_panel = QFrame()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setSpacing(15)

        # Posture status label
        self.alert_label = QLabel("No Posture Issues")
        self.alert_label.setObjectName("alertLabel")
        right_layout.addWidget(self.alert_label)

        # Timer label
        self.timer_label = QLabel("Bad Posture Duration: 0 s")
        self.timer_label.setStyleSheet("color: #ccc; font-size: 14px;")
        right_layout.addWidget(self.timer_label)

        # Confidence slider
        self.conf_slider = QSlider(Qt.Horizontal)
        self.conf_slider.setRange(50, 90)  # 0.50..0.90
        self.conf_slider.setValue(70)      # default .70
        self.conf_slider.valueChanged.connect(self.on_confidence_changed)
        right_layout.addWidget(self.conf_slider)

        # Button to set baseline posture
        self.baseline_button = QPushButton("Set Baseline Posture")
        self.baseline_button.clicked.connect(self.on_set_baseline)
        right_layout.addWidget(self.baseline_button)

        # "Alert" button that we will blink
        self.alert_button = QPushButton("ALERT")
        self.alert_button.setStyleSheet("background-color: #444; color: #fff; font-size: 16px;")
        self.alert_button.setVisible(False)  # hidden initially
        right_layout.addWidget(self.alert_button)

        right_layout.addStretch()

        splitter = QSplitter(Qt.Horizontal)
        left_frame = QFrame()
        left_layout = QVBoxLayout(left_frame)
        left_layout.addWidget(self.video_label)

        splitter.addWidget(left_frame)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(0, 6)
        splitter.setStretchFactor(1, 4)

        main_layout.addWidget(splitter)

    # -----------------------
    # UI Callbacks
    # -----------------------
    def on_confidence_changed(self):
        """Adjust detection confidence threshold."""
        val = self.conf_slider.value()
        conf_thres = float(val) / 100.0
        if self.detector.model:
            self.detector.model.overrides["conf"] = conf_thres

    def on_set_baseline(self):
        """
        Force the system to save the current posture as the baseline.
        We'll rely on the last frame's keypoints from the worker if available.
        Since we can't directly grab them, we'll keep a 'last_keypoints' in the UI.
        """
        if not self.last_keypoints or len(self.last_keypoints) < 15:
            QMessageBox.warning(self, "Baseline Error", "No valid posture detected to set as baseline.")
            return

        self.anomaly_detector.set_baseline(self.last_keypoints)
        QMessageBox.information(self, "Baseline Set", "Your current posture has been saved as the baseline.")

    # -----------------------
    # Real-Time Frame Handling
    # -----------------------
    def on_frame_ready(self, annotated_frame, keypoints, is_bad_posture):
        # Keep track of keypoints for baseline saving
        self.last_keypoints = keypoints

        # Convert to QImage
        rgb_frame = cv2.cvtColor(annotated_frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        qt_image = QImage(rgb_frame.data, w, h, ch * w, QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(qt_image))

        now = time.time()
        if is_bad_posture:
            if self.bad_posture_start is None:
                self.bad_posture_start = now
        else:
            self.bad_posture_start = None

        duration = 0
        if self.bad_posture_start is not None:
            duration = now - self.bad_posture_start
            self.timer_label.setText(f"Bad Posture Duration: {int(duration)} s")
        else:
            self.timer_label.setText("Bad Posture Duration: 0 s")

        # 4-minute rule for continuous bad posture
        if duration >= self.BAD_POSTURE_THRESHOLD:
            self.alert_label.setText("ALERT: Please correct your posture!")
            self.alert_label.setStyleSheet("color: #f00; font-size: 18px;")
        else:
            if is_bad_posture:
                self.alert_label.setText("Posture Issue Detected")
                self.alert_label.setStyleSheet("color: #f0c000; font-size: 18px;")
            else:
                self.alert_label.setText("No Posture Issues")
                self.alert_label.setStyleSheet("color: #0f0; font-size: 18px;")

        # Also control the Alert button (blink) if posture is bad
        self.alert_button.setVisible(is_bad_posture)

    # -----------------------
    # Alert Blinking
    # -----------------------
    def _toggle_alert_button(self):
        """Called by blink_timer. Toggles the 'ALERT' button color."""
        if not self.alert_button.isVisible():
            return
        self.alert_blink_state = not self.alert_blink_state
        if self.alert_blink_state:
            self.alert_button.setStyleSheet("background-color: red; color: white; font-size: 16px;")
        else:
            self.alert_button.setStyleSheet("background-color: #444; color: #fff; font-size: 16px;")

    def closeEvent(self, event):
        self.worker.stop()
        self.worker.wait()
        self.detector.close_camera()
        super().closeEvent(event)

def main():
    app = QApplication(sys.argv)
    window = PostureApp()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
    app.run(port=5000, debug=True)